from django.apps import AppConfig


class NashkartConfig(AppConfig):
    name = 'Nashkart'
