This is a Django Ecommerce Applicaion .
